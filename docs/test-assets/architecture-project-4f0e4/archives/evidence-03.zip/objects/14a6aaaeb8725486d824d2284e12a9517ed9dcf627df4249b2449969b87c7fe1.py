from pathlib import Path
import json,os,shutil
from app.main import _sanitize_agent_reply
out=Path.cwd()/'runtime/native-recovery-20261014';p=Path.cwd()/'runtime/projects/architecture-project-4f0e4'
log=next((Path(os.environ['LOCALAPPDATA'])/'AI Architecture Studio/CodexHome/sessions').rglob('*01a1386c-fe2d-7301-94cd-2d2b7f70baf9.jsonl'))
raw=None
for line in log.read_text(encoding='utf-8').splitlines():
 d=json.loads(line);v=d.get('payload',{})
 if d.get('type')=='response_item' and v.get('role')=='assistant' and v.get('phase')=='final_answer':
  raw=''.join(c.get('text','') for c in v.get('content',[]) if c.get('type')=='output_text')
assert raw and 'direction_sketch.png' in raw
reply=_sanitize_agent_reply(raw,p);assert '](notes/direction_sketch.png)' in reply
sessionpath=p/'state/agent_session.json';contextpath=p/'state/project_context.json'
for f in (sessionpath,contextpath):shutil.copy2(f,out/('pre-diagram-display-'+f.name))
s=json.loads(sessionpath.read_text(encoding='utf-8'));old=s['last_reply'];s['last_reply']=reply
c=json.loads(contextpath.read_text(encoding='utf-8'));assert c['conversation'][-1]['content']==old;c['conversation'][-1]['content']=reply
sessionpath.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8');contextpath.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'diagram-display-recovery.json').write_text(json.dumps({'source':'actual retained native site final response','native_thread':'01a1386c-fe2d-7301-94cd-2d2b7f70baf9','old_reply':old,'new_reply':reply,'new_inference':False},ensure_ascii=False,indent=2),encoding='utf-8')
print('Restored actual site diagram link; no new inference or authored assistant response.')

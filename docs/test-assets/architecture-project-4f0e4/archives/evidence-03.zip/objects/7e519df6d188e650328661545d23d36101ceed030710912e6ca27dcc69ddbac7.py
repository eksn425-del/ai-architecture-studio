from pathlib import Path
import json,uuid
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP,_generated_script_dir
from scripts.compare_native_replay import compare
out=Path.cwd()/'runtime/native-recovery-20261014';ad=SketchUpAdapter();identity=ad.get_active_model_identity();model=Path(identity['model_path'])
tag='-v2'
expected=(out/'controlled/projects/architecture-project-4f0e4/outputs/model/blank-disposable-parent-first-FRESH-bound.skp').resolve()
assert model.resolve()==expected
pid=json.loads((out/'parent-first-identity.json').read_text())['root_pid']
before=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=identity['model_guid'],root_pid=pid,output_path=out/('guards-before'+tag+'.json'))
helper=(Path.cwd()/'app/vendor/sketchup_architect/scripts/model_session.rb').as_posix()
script=_generated_script_dir()/('studio-p0-guard-'+uuid.uuid4().hex+'.rb')
script.write_text('''# ARCHFLOW_GENERATED_SCRIPT
load HELPER
model=Sketchup.active_model
raise 'Wrong safe copy' unless File.expand_path(model.path)==File.expand_path(MODEL)
raise 'Wrong GUID' unless model.guid==GUID
results={}
begin
 CodexSketchupArchitect.run(project_id:'native-regroup-smoke',expected_guid:model.guid,expected_revision:0,report_path:REGROUP_REPORT) do |m,root|
  child=root.entities.add_group
  child.entities.add_face([0,0,0],[1,0,0],[0,1,0])
  root.entities.add_group [child]
 end
rescue StandardError => error
 results[:regroup_rejected]=error.message.include?('outside its owned root')
 results[:regroup_error]=error.message
end
begin
 CodexSketchupArchitect.run(project_id:'native-keep-256-smoke',expected_guid:model.guid,expected_revision:0,report_path:KEEP_REPORT) do |m,root|
  expectations=(0...256).map do |i|
   g=root.entities.add_group;g.name="KEEP_#{i}"
   g.entities.add_face([i*2,0,0],[i*2+1,0,0],[i*2+1,1,0],[i*2,1,0])
   snapshot=KStudioProfessionalHelpers.inspect_named_owned_group(root,[g.name],0,1)
   { 'path'=>[g.name], 'persistent_id'=>g.persistent_id, 'objects_total'=>0,
     'bounds_mm'=>JSON.parse(JSON.generate(snapshot[:bounds_mm])) }
  end
  receipt=KStudioProfessionalHelpers.verify_owned_fingerprints!(root,expectations)
  results[:keep_paths_checked]=receipt[:checks].length
  last=root.entities.to_a.last
  last.transform!(Geom::Transformation.translation([0,0,1]))
  begin
   KStudioProfessionalHelpers.verify_owned_fingerprints!(root,expectations)
  rescue StandardError => error
   results[:keep_mutation_rejected]=true
   results[:keep_mutation_error]=error.message
  end
  raise 'ROLLBACK_ONLY_DIAGNOSTIC'
 end
rescue StandardError => error
 results[:keep_rolled_back]=error.message=='ROLLBACK_ONLY_DIAGNOSTIC'
 results[:keep_error]=error.message
end
results
'''.replace('HELPER',json.dumps(helper)).replace('MODEL',json.dumps(expected.as_posix())).replace('GUID',json.dumps(identity['model_guid'])).replace('REGROUP_REPORT',json.dumps((out/('regroup-native-transaction-report'+tag+'.json')).as_posix())).replace('KEEP_REPORT',json.dumps((out/('keep256-native-transaction-report'+tag+'.json')).as_posix())),encoding='utf-8')
try:
 raw=ConfiguredSketchUpMCP(timeout_seconds=120).call('sketchup_eval_project_file',{'script_path':str(script),'operation_name':'P0 native owned-scope and KEEP 256 rollback diagnostics'})
finally:script.unlink()
(out/('guard-native-results'+tag+'.json')).write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
i=ad.get_active_model_identity();after=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=pid,output_path=out/('guards-after'+tag+'.json'))
r=compare(before,after);(out/('guard-deep-rollback-comparison'+tag+'.json')).write_text(json.dumps(r,indent=2),encoding='utf-8')
print(raw['result']);print('Whole-document rollback:',r['status'])

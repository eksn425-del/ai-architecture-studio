from pathlib import Path
import json,shutil,uuid
from app.sketchup_mcp import SketchUpAdapter
from app.spatial_spec import validate_spatial_spec
p=Path.cwd()/'runtime/projects/architecture-project-4f0e4';out=Path.cwd()/'runtime/native-recovery-20261014'
assert json.loads((out/'owned-copy-three-stage-audit.json').read_text())['status']=='PASS'
model=p/'outputs/model/blank-disposable-p0-repaired-r2.skp';ad=SketchUpAdapter();i=ad.get_active_model_identity();assert Path(i['model_path']).resolve()==model.resolve()
deep=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=20606,output_path=out/('site-before-edit-r2-'+uuid.uuid4().hex[:6]+'.json'))
expected=json.loads((out/'owned-copy-live-before-save.json').read_text(encoding='utf-8'));assert deep['document_geometry_material_sha256']==expected['document_geometry_material_sha256']
spec=json.loads((p/'runtime/agent_workspace/notes/spatial_spec.json').read_text(encoding='utf-8'));validation=validate_spatial_spec(spec);assert validation['status']=='AGENT_REVIEWED_OWNER_DELEGATED',validation
(out/'spatial-spec-delegated-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
for relative in ('state/agent_session.json','runtime/project_ruby_state.json','state/model_state.json'):
 f=p/relative;shutil.copy2(f,out/('pre-working-copy-bind-'+f.name))
s=json.loads((p/'state/agent_session.json').read_text(encoding='utf-8'));r=json.loads((p/'runtime/project_ruby_state.json').read_text(encoding='utf-8'));m=json.loads((p/'state/model_state.json').read_text(encoding='utf-8'))
report=json.loads((out/'owned-copy-native-repair-report.json').read_text(encoding='utf-8'));assert report['revision']==2 and report['root_pid']==20606
for scripts in (s['ruby_state'],r['scripts']):
 state=scripts['glass_curved_roof'];state['revision']=2;state['model_guid']=i['model_guid'];state['last_report']='../../../native-recovery-20261014/owned-copy-native-repair-report.json'
 state['last_verification']={'verified':True,'source':'native_readonly_three_stage_r2_delivery','root_pid':20606,'revision':2,'document_geometry_material_sha256':deep['document_geometry_material_sha256']}
 state['p0_native_repair']={'status':'PASS','zero_model_calls':True,'original_revision':1,'historical_source_sha256':state['source_sha256']}
s['model_path']=model.relative_to(p).as_posix();s['model_guid']=i['model_guid'];s['reconstruction_state']='building';s['error']=''
r['model_path']=str(model);m['model_path']='outputs/model/p0-repaired-candidate-r2.skp';m['last_operation']={'action':'native_P0_safe_copy_repair','status':'committed','root_pid':20606,'revision':2,'website_model_edit':False}
for rel,value in [('state/agent_session.json',s),('runtime/project_ruby_state.json',r),('state/model_state.json',m)]: (p/rel).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'working-copy-bind-receipt.json').write_text(json.dumps({'project_id':p.name,'root_pid':20606,'revision':2,'model_path':str(model),'guid':i['model_guid'],'status':'P0_VERIFIED_READY_FOR_SAME_PROJECT_LOCAL_EDIT','authorization':'Owner continuation and delegated source direction review; existing approved building, no new full construction','baseline_hash':deep['document_geometry_material_sha256']},ensure_ascii=False,indent=2),encoding='utf-8')
print('Same project/root now bound to verified safe r2; existing original r1 SKPs preserved.')

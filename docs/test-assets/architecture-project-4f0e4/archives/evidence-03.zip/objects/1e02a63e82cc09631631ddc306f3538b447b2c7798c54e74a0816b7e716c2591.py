from pathlib import Path
import json
out=Path.cwd()/'runtime/native-recovery-20261014';load=lambda n:json.loads((out/n).read_text(encoding='utf-8'))
before=load('owned-copy-live-before-save.json');after=load('site-r3-live-before-checkpoint.json')
a={g['name']:g for g in before['groups']};b={g['name']:g for g in after['groups']};assert set(a)==set(b)
changed=[n for n in a if a[n]['geometry_material_sha256']!=b[n]['geometry_material_sha256']]
assert set(changed)=={'ROOF_TIMBER','ENVELOPE_OUTER'},changed
e0={g['name']:g for g in a['ENVELOPE_OUTER']['children']};e1={g['name']:g for g in b['ENVELOPE_OUTER']['children']};assert set(e0)==set(e1)
ec=[n for n in e0 if e0[n]['geometry_material_sha256']!=e1[n]['geometry_material_sha256']];assert ec==['TENSION_BRACING'],ec
protected={n:a[n]['pid']==b[n]['pid'] and a[n]['geometry_material_sha256']==b[n]['geometry_material_sha256'] for n in a if n not in changed}
protected.update({'ENVELOPE_OUTER/'+n:e0[n]['pid']==e1[n]['pid'] and e0[n]['geometry_material_sha256']==e1[n]['geometry_material_sha256'] for n in e0 if n not in ec});assert all(protected.values())
report={'status':'PASS','source':'actual native deep readback hashes and persistent IDs','before_revision':2,'after_revision':3,'root_pid':20606,'changed_direct_groups':changed,'changed_envelope_children':ec,'unchanged_deep_paths':protected,'unchanged_deep_path_count':len(protected),'note':'Roof and its tension bracing changed; glass/frame/canopies, ramps, floors, structure and interior protected. Entire building was not transformed.'}
(out/'site-r3-deep-keep.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('Deep KEEP PASS',len(protected),'paths; changes only roof + tension bracing')

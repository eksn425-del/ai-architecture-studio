from pathlib import Path
import json, shutil, re, hashlib
ROOT=Path(__file__).resolve().parents[2]
P=Path(__file__).resolve().parent
C=ROOT/'runtime/native-recovery-20261014/codex-control/projects/architecture-project-4f0e4'
D=ROOT/'docs/test-results/windows/2026-10-14-authorized-original-codex-control'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def clean(x):
    if isinstance(x,dict): return {k:clean(v) for k,v in x.items()}
    if isinstance(x,list): return [clean(v) for v in x]
    if isinstance(x,str):
        x=x.replace(str(ROOT),'[PRIVATE_REPO]').replace(str(ROOT).replace('\\','/'),'[PRIVATE_REPO]')
        if re.match(r'^[A-Za-z]:[\\/]',x): return '[PRIVATE_HOST_PATH]'
        return x
    return x
def write(name,x):
    f=D/name; f.parent.mkdir(parents=True,exist_ok=True)
    f.write_text(json.dumps(clean(x),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def deep_summary(name):
    x=load(P/name)
    return {k:v for k,v in x.items() if k not in {'groups','document_groups','global_entities'}} | {'private_full_evidence_sha256':hashlib.sha256((P/name).read_bytes()).hexdigest(),'raw_private_native_geometry_uploaded':False}
D.mkdir(parents=True,exist_ok=True)
for v in ('front','rear','left','right','roof','oblique'):
    (D/'views').mkdir(exist_ok=True)
    shutil.copy2(P/f'final-control-r3/{v}.png',D/f'views/{v}.png')
    write(f'views/{v}.evidence.json',load(P/f'final-control-r3/{v}.evidence.json'))
shutil.copy2(P/'final-control-r3/source-perspective.png',D/'source-perspective.png')
state=load(C/'runtime/project_ruby_state.json')['scripts']['glass_curved_roof']
write('model/write-verifications.json',{k:v for k,v in state.items() if k.startswith('last_')})
write('model/oss-method-ledger.json',state['last_oss_method_ledger'])
write('model/oss-method-adoption.json',state['last_oss_method_adoption'])
write('model/geometry-readback.json',deep_summary('control-after-before-save.json'))
write('model/native-reopen.json',{'actual_stages':{n:deep_summary(n) for n in ['control-after-before-save.json','control-bound-reopened.json','control-candidate-reopened.json']},'audit':load(P/'control-three-stage-native-audit.json'),'candidate_open':'Native SketchUp guarded lifecycle API; generated saved candidate, NOT browser download','browser_download_control':'NOT_RUN','strict_blank_replay':'NOT_RUN','separate_mouse_edit_control':'NOT_RUN'})
write('model/native-save-receipt.json',load(P/'control-native-delivery-receipt.json'))
write('model/deep-keep-and-site-comparison.json',load(P/'actual-deep-keep-and-site-comparison.json'))
review=load(P/'independent-control-critic.json')
write('review/critique.json',review)
(D/'review/review.md').write_text('# 独立只读审查\n\n实际独立 Sol Medium / readOnly / 无写工具；不是 Builder 自评。NEEDS_FIX: YES。\n\n'+review['critique']+'\n\n现有未剖切外观不能认证室内洞口、节点或尺寸。局部方向及保护通过，不等于整栋源图质量通过。\n',encoding='utf-8')
attempts=[]
for stem in ['original-codex-exec','original-codex-boundary-retry','original-codex-fixed-transport']:
    events=[json.loads(s) for s in (P/f'{stem}.jsonl').read_text(encoding='utf-8-sig').splitlines() if s.strip()]
    usage=next((e.get('usage') for e in reversed(events) if e.get('type')=='turn.completed'),None)
    items=[e.get('item',{}) for e in events if e.get('type')=='item.completed']
    mcps=[i for i in items if i.get('type')=='mcp_tool_call']
    attempts.append({'attempt':stem,'timing':load(P/f'{stem}-timing.json'),'usage':usage,'mcp_completed':len(mcps),'mcp_failed':sum(i.get('status')=='failed' or bool(i.get('error')) for i in mcps),'completed_item_counts':{t:sum(i.get('type')==t for i in items) for t in sorted({i.get('type','unknown') for i in items})},'geometry_committed':stem.endswith('fixed-transport')})
write('comparison/attempts.json',attempts)
write('comparison/model-identity.json',load(P/'actual-cli-model-identity.json'))
write('comparison/transport-fix.json',{'observed':'MCP subprocess inherited session stdin; host launch delayed until timeout/session close. stdout file-spool hypothesis tested and failed.','retained_fix':'subprocess.run(..., stdin=subprocess.DEVNULL, capture_output=True, ...)', 'actual_fixed_mcp_inspect_elapsed_seconds':1.33,'writer_or_approval_guard_changed':False})
success=attempts[-1]; known=[a['usage'] for a in attempts if a['usage']]
write('metrics.json',{'schema_version':1,'elapsed_ms':sum(a['timing']['elapsed_ms'] for a in attempts),'elapsed_scope':'All three actual CLI attempt wall times; native diagnostics, backups, UI/user pauses and separate Critic excluded.','tool_call_count':success['mcp_completed'],'tool_count_scope':'Successful attempt MCP completions only; standard CLI item counts retained separately, not comparable to website aggregate tool count','failed_tool_calls':success['mcp_failed'],'committed_writes':1,'full_root_rebuilds':0,'targeted_corrections':1,'input_tokens':sum(u.get('input_tokens',0) for u in known),'output_tokens':sum(u.get('output_tokens',0) for u in known),'token_source':'Actual turn.completed usage; reported subtotal excludes initial quota-blocked attempt whose usage is null. Preserve all attempts.','successful_attempt_usage':success['usage'],'successful_attempt_elapsed_ms':success['timing']['elapsed_ms'],'critic_input_tokens':review['_reviewer']['input_tokens'],'critic_output_tokens':review['_reviewer']['output_tokens'],'critic_elapsed_ms':review['_reviewer']['latency_ms'],'outer_controller_tokens':None,'paid_api_calls':0,'local_usage_caps':0})
write('run.json',{'schema_version':1,'test_id':D.name,'status':'PARTIAL','geometry_committed':True,'base_commit':'cf7107a6be37844d566fe2a75b16ba6840bf9631','source_case':'Same eight private whole original references, original project architecture-project-4f0e4 and owned root20606, repaired r2 baseline; isolated safe control directory, no new architecture case.','model':{'requested':'GPT-6.1 Sol / Medium','actual':'gpt-6.1-sol','reasoning_effort':'medium','runtime':'Actual original codex exec CLI, same ChatGPT account, approved process-only guarded MCP; outer controller unchanged'},'environment':{'windows':'Windows 11','sketchup':'2024 / 24.0.484','bridge':'Existing ProjectRuby/Kongxing guarded sole writer'},'revision':3,'root_pid':20606,'qa':{'reviewer_mode':'dedicated_read_only','fidelity_status':'FAIL','needs_fix':True,'local_roof_direction':'PASS','deep_keep':'PASS','native_delivery':'PASS for actual saved bound/candidate reopen','website_r3_exact_document_geometry':'PASS equal SHA','strict_blank_replay':'NOT_RUN','control_browser_download':'NOT_RUN'},'blockers':['Whole-source fidelity still FAIL; independent reviewer identifies wide solid bracing instead of fine tension cables.','Control has fresh CLI context and post-hoc independent Critic; website had resumed context and pre/post Critic, so timings are not provider performance rankings.'],'private_sources_and_skp_uploaded':False})
write('errors.json',[{'stage':'initial original CLI','status':'BLOCKED','reason':'Account usage limit error; no write, no final token receipt; no quota reset or purchase used.'},{'stage':'boundary retry','status':'FAIL','reason':'Approved MCP inspect/source_view timed out; no geometry write. Inherited subprocess stdin proven; file-spool stdout hypothesis failed.'},{'stage':'native bound first read','status':'FAIL','reason':'Active document identity guard rejected too-early read; later native reopen verified.'},{'stage':'restore website via native lifecycle API','status':'BLOCKED','reason':'Cross-folder restore rejected by existing safety guard; guard retained. Desktop foreground switch intermittently failed; no dependent path typing or Enter.'}])
text='''# 同八张原图：原版 Codex 实际局部对照（2026-10-14）

总体 PARTIAL：原版一次屋顶方向局部修改 PASS，119 个保护路径深层几何/材质和 PID 不变，原生保存与两份安全副本重开 PASS；整栋源图相似度仍 FAIL。

所有者明确允许后，只给本次进程的单个 guarded MCP 工具设置 approve。CLI 仍 workspace-write、approval_policy never，原始写工具禁用，既有 ProjectRuby 身份/范围/KEEP/一次写入限制保持。八张原图 SHA 和顺序及 r2 起点已实际核对，网站 r4、原始 r1 和私人资源先备份。

原版输入与网站 r2→r3 相同：『从坡道这一端看，屋顶还是左边偏高。请按原图改成右边高、左边低，保留曲面，坡道和其他部分别动。』实际 gpt-6.1-sol / medium，没有换模型、重建整栋或付费 API。

实际完整文档几何指纹为 `2f9c218c4a15dc20ad39bac7fe8cdf90234847f880a135db0e7efd5f95ce8719`，与网站 r3 **完全相同**。两边都反射既有屋顶并对随附 TENSION_BRACING 做对应局部转换；不是全楼翻转。不能据此说原版提高了空间理解或整栋源图质量。

成功 CLI 耗时393951ms，input1265869 / output7282，cached1171968；网站原方向修改实际536656ms，Builder input3431345 / output7112，52聚合工具调用，另有两次 Critic input131156 / output1437。两者上下文、工具包装、Critic调用位置不同，时间和 Token 是本次观测值，不能解释为公平的模型速度/价格排名。

保留前两次失败：第一次78146ms账户配额报错，无最终Token记录；第二次495262ms只读MCP超时，无写入，input982531 / output1649。查明子进程继承 MCP 会话 stdin；stdout改文件的假设测试失败，最终仅加 stdin=DEVNULL，真实 SDK inspect1.33s返回。没有修改模型权限或产品几何后端。

仓库历史开发 AGENTS 还污染了 CLI 工作目录，触发无关 Git/CURRENT 查找。隔离根标记后实际原版执行正常；产品 Native Agent 已加入 .kstudio-agent-root/project_root_markers，沙箱/授权/联网/写目录不变。436 passed、2 skipped。网站新边界真实复测 NOT_RUN，不可拿代码测试当建模质量 PASS。

独立只读 Sol Medium Critic 91422ms、input47588 / output874、0工具，NEEDS_FIX YES：曲顶两侧斜撑成为厚实三角带，遮住通道，与原图细拉索不符；未剖切截图不能证明室内洞口或真实连接。保留曲顶轮廓和折返坡道总体组织，不应整栋重试。下一步应先只读核对同项目 r4 的斜撑拓扑/截面，再制定最小局部修复，不以原版成功替代网站验收。

原版交付候选是真实保存副本，原生 guarded lifecycle API 打开；不是浏览器下载。审计脚本字段 clean_download 在本对照中仅指该干净候选；原版浏览器下载、单独鼠标编辑和最终严格空白 replay NOT_RUN。网站 r4 的实际浏览器下载与 native reopen 已由上一报告证明。

六张图与 sidecar 均为本次真实控制 r3。私人八张图片、SKP、原始执行日志、账号及密钥未上传。保留完整失败及实际用量；未知 Token 为 null，所有本地成本上限为0，未重置历史用量。
'''
(D/'README.md').write_text(text,encoding='utf-8')
print(json.dumps({'attempts':attempts,'report':str(D)},ensure_ascii=False))

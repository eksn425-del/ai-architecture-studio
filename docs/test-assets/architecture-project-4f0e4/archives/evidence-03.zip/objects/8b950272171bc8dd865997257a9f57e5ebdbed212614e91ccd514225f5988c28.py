from pathlib import Path
import os,json,time
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP
from app.project_ruby import ProjectRubyExecutor
os.environ['ARCH_STUDIO_ENABLE_ADAI_GEOMETRY']='1'
root=Path.cwd();out=root/'runtime/native-recovery-20261014';controlled=out/'controlled'
model=controlled/'projects/architecture-project-4f0e4/outputs/model/blank-disposable-deterministic-replay.skp'
client=ConfiguredSketchUpMCP(timeout_seconds=120)
ad=SketchUpAdapter(client);i=ad.get_active_model_identity()
source=(root/'runtime/projects/architecture-project-4f0e4/runtime/scripts/glass_curved_roof.rb').read_text(encoding='utf-8')
tools=ProjectRubyExecutor(controlled,'architecture-project-4f0e4',expected_model_path=model,expected_model_guid=i['model_guid'],mcp=client,adapter=ad)
started=time.monotonic()
result=tools.run({'script_id':'glass_curved_roof','ruby_source':source})
(out/'original-replay-writer.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
i=ad.get_active_model_identity();pid=tools.ruby_state['glass_curved_roof']['root_pid']
p=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=pid,output_path=out/'original-replay-live-before-save.json')
print('Elapsed:',round(time.monotonic()-started,2),'root:',pid,'doc groups:',[(g['name'],g['counts']) for g in p['document_groups']])
(out/'original-replay-identity.json').write_text(json.dumps(i|{'root_pid':pid}),encoding='utf-8')

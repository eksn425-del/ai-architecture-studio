from pathlib import Path
import os,json,time,shutil
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP
from app.project_ruby import ProjectRubyExecutor
from app.native_delivery import record_delivery_checkpoint
os.environ['ARCH_STUDIO_ENABLE_ADAI_GEOMETRY']='1'
root=Path.cwd();out=root/'runtime/native-recovery-20261014';controlled=out/'controlled'
project=controlled/'projects/architecture-project-4f0e4'
model=project/'outputs/model/blank-disposable-parent-first-replay.skp'
client=ConfiguredSketchUpMCP(timeout_seconds=120);ad=SketchUpAdapter(client);i=ad.get_active_model_identity()
source=(out/'parent-first-reconstruction.rb').read_text(encoding='utf-8')
tools=ProjectRubyExecutor(controlled,'architecture-project-4f0e4',expected_model_path=model,expected_model_guid=i['model_guid'],mcp=client,adapter=ad)
started=time.monotonic()
r=tools.run({'script_id':'glass_curved_roof','ruby_source':source})
(out/'parent-first-writer.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
i=ad.get_active_model_identity();pid=tools.ruby_state['glass_curved_roof']['root_pid']
p=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=pid,output_path=out/'parent-first-live-before-save.json')
ad.save_model(model,expected_root_ids=[pid]);download=project/'outputs/model/parent-first-download.skp';ad.save_model(download,expected_root_ids=[pid])
receipt=record_delivery_checkpoint(project,model,download,roots=[pid],revisions={'glass_curved_roof':1})
(out/'parent-first-delivery-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
shutil.copy2(model,project/'outputs/model/blank-disposable-parent-first-FRESH-bound.skp')
(out/'parent-first-identity.json').write_text(json.dumps(ad.get_active_model_identity()|{'root_pid':pid,'elapsed_s':time.monotonic()-started}),encoding='utf-8')
print('parent-first root:',pid,'document:',[(g['name'],g['counts']['faces']) for g in p['document_groups']])

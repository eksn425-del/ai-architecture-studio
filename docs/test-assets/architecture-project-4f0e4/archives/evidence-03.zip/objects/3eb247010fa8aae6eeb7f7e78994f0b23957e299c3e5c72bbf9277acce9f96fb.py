from pathlib import Path
import json,uuid
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP,_generated_script_dir
from app.native_delivery import record_delivery_checkpoint
out=Path.cwd()/'runtime/native-recovery-20261014';project=Path.cwd()/'runtime/projects/architecture-project-4f0e4'
model=project/'outputs/model/blank-disposable-p0-repaired-r2.skp';ad=SketchUpAdapter();i=ad.get_active_model_identity()
before=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=20606,output_path=out/'owned-copy-before-repair.json')
historic=json.loads((out/'historic-download-deep-v2.json').read_text(encoding='utf-8'))
assert before['document_geometry_material_sha256']==historic['document_geometry_material_sha256']
helper=(Path.cwd()/'app/vendor/sketchup_architect/scripts/model_session.rb').as_posix()
script=_generated_script_dir()/('studio-p0-owned-repair-'+uuid.uuid4().hex+'.rb')
script.write_text('''# ARCHFLOW_GENERATED_SCRIPT
load HELPER
model=Sketchup.active_model
raise 'Wrong protected copy' unless File.expand_path(model.path)==File.expand_path(MODEL)
raise 'Wrong live GUID' unless model.guid==GUID
root=model.find_entity_by_persistent_id(20606)
raise 'Expected r1 root missing' unless root.get_attribute('sketchup_architect','revision')==1
containers={}
{ 'FLOORS'=>23870,'ROOF_TIMBER'=>28004,'RAMPS'=>41186,'INTERIOR'=>75611 }.each do |name,pid|
 g=model.entities.find{|e|e.persistent_id==pid}
 raise "Wrong escaped container #{name}" unless g.is_a?(Sketchup::Group) && g.name==name
 raise "Nonempty leaked container #{name}" unless name=='INTERIOR' || g.entities.length==0
 containers[name]=g
end
CodexSketchupArchitect.run(project_id:'architecture-project-4f0e4',expected_guid:model.guid,expected_revision:1,root_pid:20606,report_path:REPORT) do |m,owned|
 { 'FLOORS'=>%w[L0 L1 L2_PARTIAL_SOUTH L2_PARTIAL_EAST L3],
   'ROOF_TIMBER'=>%w[CURVED_SHELL ROOF_SUPPORTS],
   'RAMPS'=>%w[RAMP_1 RAMP_2 RAMP_3] }.each do |container_name,names|
  parent=owned.entities.add_group;parent.name=container_name
  names.each do |name|
   matches=owned.entities.select{|g|g.respond_to?(:name) && g.name==name}
   raise "Ambiguous original #{name}" unless matches.length==1
   old=matches.first
   # The failed regroup subtracted the escaped container transform without
   # moving this entity out of root. Compose back that exact observed matrix.
   restored=containers[container_name].transformation*old.transformation
   fresh=parent.entities.add_instance(old.definition,restored)
   fresh.name=name;fresh.material=old.material
   old.erase!
  end
 end
 owned.entities.select{|g|g.respond_to?(:name) && g.name.start_with?('PARTITION_')}.each do |wall|
  wall.transformation=containers['INTERIOR'].transformation*wall.transformation
 end
 old=containers['INTERIOR']
 fresh=owned.entities.add_instance(old.definition,Geom::Transformation.new)
 fresh.name='INTERIOR';fresh.material=old.material
 # Only the four PID/name-verified leaked instances are removed. Definitions
 # remain alive through the inserted owned instances; no full-root rebuild.
 containers.each_value{|g|g.erase!}
end
{ root_pid:20606,revision:2,repair:'inverse_observed_regroup_and_restore_owned_parentage' }
'''.replace('HELPER',json.dumps(helper)).replace('MODEL',json.dumps(model.resolve().as_posix())).replace('GUID',json.dumps(i['model_guid'])).replace('REPORT',json.dumps((out/'owned-copy-native-repair-report.json').as_posix())),encoding='utf-8')
try:raw=ConfiguredSketchUpMCP(timeout_seconds=120).call('sketchup_eval_project_file',{'script_path':str(script),'operation_name':'P0 evidence-backed regroup repair on owned safe copy'})
finally:script.unlink()
(out/'owned-copy-repair-result.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
i=ad.get_active_model_identity();after=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=i['model_guid'],root_pid=20606,output_path=out/'owned-copy-live-before-save.json')
protected=['STRUCTURE_EXISTING','CIRCULATION_EXTERNAL','CIRCULATION_INTERNAL','ENVELOPE_OUTER','SITE_GROUND']
a={g['name']:g for g in before['groups']};b={g['name']:g for g in after['groups']}
keep={n:a[n]['geometry_material_sha256']==b[n]['geometry_material_sha256'] and a[n]['pid']==b[n]['pid'] for n in protected}
assert all(keep.values())
(out/'owned-copy-deep-keep.json').write_text(json.dumps({'status':'PASS','unchanged_named_direct_groups':keep,'scope':'Five unaffected primary systems, full nested geometry/material SHA and persistent IDs; corrected assembly systems excluded.'},indent=2),encoding='utf-8')
ad.save_model(model,expected_root_ids=[20606]);candidate=project/'outputs/model/p0-repaired-candidate-r2.skp';ad.save_model(candidate,expected_root_ids=[20606])
receipt=record_delivery_checkpoint(project,model,candidate,roots=[20606],revisions={'glass_curved_roof':2})
(out/'owned-copy-delivery-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print('Owned root 20606 r1 -> r2 on safe copy. Deep protected systems:',keep)
print('Document groups:',[(g['name'],g['counts']['faces']) for g in after['document_groups']])

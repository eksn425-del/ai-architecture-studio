from pathlib import Path
import json,hashlib,shutil,re,gzip
repo=Path.cwd();private=repo/'runtime/native-recovery-20261014';project=repo/'runtime/projects/architecture-project-4f0e4';public=repo/'docs/test-results/windows/2026-10-14-eight-source-quality-recovery'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def clean(value):
 if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
 if isinstance(value,list):return [clean(v) for v in value]
 if isinstance(value,str):
  if re.match(r'^[A-Za-z]:[\\/]',value):return '<private>/'+re.split(r'[\\/]',value)[-1]
  value=value.replace(str(repo),'<private-workspace>').replace(repo.as_posix(),'<private-workspace>')
  return re.sub(r'C:[\\/]Users[\\/][^\\/\s]+','<private-user>',value)
 return value
def write(relative,value):
 p=public/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(clean(value),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def copy(relative,src):
 p=public/relative;p.parent.mkdir(parents=True,exist_ok=True)
 if src.suffix=='.json':write(relative,load(src))
 else:shutil.copy2(src,p)
for name in ('front','rear','left','right','roof','oblique'):
 for suffix in ('.png','.evidence.json'):copy('views/'+name+suffix,private/'site-final-r3'/(name+suffix))
copy('source-perspective.png',private/'site-final-r3/source-perspective.png')
copy('before/source-perspective-r2.png',private/'site-before-r2/source-perspective.png')
copy('before/original-replay-reopened-oblique.png',private/'original-replay-reopened-oblique.png')
copy('website/natural-roof-request.png',private/'site-natural-roof-request.png')
copy('website/roof-result-r3.png',private/'site-roof-result-r3.png')
copy('planning/direction-sketch.png',project/'runtime/agent_workspace/notes/direction_sketch.png')
for name in ('reconstruction_evidence.json','facade_schedule.json','construction_strategy.json','spatial_spec.json'):copy('planning/'+name,project/'runtime/agent_workspace/notes'/name)
copy('planning/validation.json',private/'spatial-spec-delegated-validation.json')
for n in ('original-replay-three-stage-audit.json','parent-first-three-stage-audit.json','owned-copy-three-stage-audit.json','site-r3-three-stage-audit.json','owned-copy-deep-keep.json','site-r3-deep-keep.json','guard-native-results-v2.json','guard-deep-rollback-comparison-v2.json','native-mouse-probe-reopen-comparison.json','owned-copy-delivery-receipt.json','site-r3-delivery-receipt.json'):copy('native/'+n,private/n)
deep_names=('original-replay-live-before-save.json','original-replay-bound-FRESH-reopened.json','original-replay-download-reopened.json','owned-copy-live-before-save.json','owned-copy-bound-reopened.json','owned-copy-browser-download-reopened.json','site-r3-live-before-checkpoint.json','site-r3-bound-reopened.json','site-r3-browser-download-reopened.json','native-mouse-probe-before.json','native-mouse-probe-after-live.json','native-mouse-probe-reopened.json')
inventory=[]
for name in deep_names:
 data=load(private/name);copy('native/deep-summary/'+name,{ } if False else private/name) if False else None
 summary={k:v for k,v in data.items() if k not in ('groups','document_groups')}
 summary['groups']=[{k:v for k,v in g.items() if k!='children'} for g in data['groups']]
 summary['document_groups']=[{k:v for k,v in g.items() if k!='children'} for g in data['document_groups']]
 summary['public_format']='Actual native deep SHA/count/transform summary; full private readback SHA preserved, private full tree not uploaded.'
 write('native/deep-summary/'+name,summary)
 inventory.append({'capture':name,'private_full_readback_sha256':hashlib.sha256((private/name).read_bytes()).hexdigest(),'document_sha256':data['document_geometry_material_sha256'],'root_sha256':data['root_geometry_material_sha256']})
write('native/deep-capture-index.json',inventory)
before=load(private/'native-mouse-probe-before.json');after=load(private/'native-mouse-probe-after-live.json');a={g['name']:g for g in before['groups']};b={g['name']:g for g in after['groups']};changed=[n for n in a if a[n]['geometry_material_sha256']!=b[n]['geometry_material_sha256']];assert changed==['ROOF_TIMBER']
probe={'status':'PASS','method':'Real native mouse selection, Move tool, blue-axis constraint, Ctrl+S, fresh filename native reopen','changed_direct_groups':changed,'roof_translation_delta_mm':[0,0,b['ROOF_TIMBER']['world_transform'][14]-a['ROOF_TIMBER']['world_transform'][14]],'unchanged_deep_direct_groups':26,'reopen':load(private/'native-mouse-probe-reopen-comparison.json'),'scope':'Separate downloaded-copy editability probe; not the website r3 model or a source fidelity repair.'}
write('model/native-reopen.json',{'site_r3_delivery':load(private/'site-r3-three-stage-audit.json'),'p0_r2_delivery':load(private/'owned-copy-three-stage-audit.json'),'native_edit_probe':probe,'strict_blank_replay_of_final_r3':'NOT_RUN','historic_r1_before_save':'BLOCKED_MISSING_HISTORICAL_CAPTURE'})
s=load(project/'state/agent_session.json');ruby=load(project/'runtime/project_ruby_state.json')['scripts']['glass_curved_roof'];report=load(project/ruby['last_report'])
write('model/write-verifications.json',{'P0_safe_copy_r1_to_r2':load(private/'owned-copy-native-repair-report.json'),'real_website_r2_to_r3':report,'verification':ruby['last_verification'],'edit_scope_receipt':ruby['last_edit_scope_receipt'],'precommit_keep_guard':ruby['last_precommit_keep_guard']})
write('model/geometry-readback.json',{'root_pid':20606,'revision':3,'owned_after':report['owned_after'],'native_deep_after':load(private/'site-r3-live-before-checkpoint.json')['root_geometry_material_sha256'],'document_deep_after':load(private/'site-r3-live-before-checkpoint.json')['document_geometry_material_sha256']})
write('model/keep-results.json',{'website_deep_keep':load(private/'site-r3-deep-keep.json'),'transaction_scope':ruby['last_edit_scope_receipt'],'transaction_bounds_keep':ruby['last_precommit_keep_guard'],'native_256_negative':load(private/'guard-native-results-v2.json')})
write('model/oss-method-ledger.json',ruby['last_oss_method_ledger']);write('model/oss-method-adoption.json',ruby['last_oss_method_adoption'])
review=load(project/'runtime/agent_workspace/qa/visual_review.json');write('review/critique.json',review)
history=[json.loads(l) for l in (project/'runtime/agent_workspace/qa/visual_review_history.jsonl').read_text(encoding='utf-8').splitlines()]
write('review/current-run-reviews.json',[r for r in history if r['model_revisions'].get('glass_curved_roof') in (2,3)])
events=[]
for f in (project/'runtime/agent_events').glob('*.jsonl'):
 if f.name not in ('28169c2b51a14af08b511f599c7576bd.jsonl','bb7f8627bac24ac0adc77788e004ad88.jsonl','91d042879fce4df19e9c07a5e924e136.jsonl','aadbcf8fc529482698565d84029d0f10.jsonl'):continue
 rows=[json.loads(l) for l in f.read_text(encoding='utf-8').splitlines()]
 events.append({'run_id':f.stem,'private_log_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'identity':next(r for r in rows if r.get('event')=='thread_model_identity'),'input':next(r for r in rows if r.get('event')=='turn_input'),'finished':next(r for r in reversed(rows) if r.get('event')=='project_budget_finished'),'failed_tools':[r for r in rows if r.get('event')=='tool_result' and not r.get('success')]})
write('model/runtime-identity-usage.json',events)
cli_runs=[]
for name,timing in [('original-codex-exec-transport-blocked.jsonl','original-codex-transport-blocked-timing.json'),('original-codex-exec.jsonl','original-codex-exec-timing.json'),('original-codex-resume-wrong-active-doc.jsonl','original-codex-resume-wrong-active-doc-timing.json'),('original-codex-resume.jsonl','original-codex-resume-timing.json')]:
 rows=[json.loads(l) for l in (private/name).read_text(encoding='utf-8').splitlines()]
 cli_runs.append({'private_log_sha256':hashlib.sha256((private/name).read_bytes()).hexdigest(),'timing':load(private/timing),'usage':next((r.get('usage') for r in reversed(rows) if r.get('type')=='turn.completed'),None),'errors':[r.get('message') or r.get('error') or r.get('item',{}).get('error') for r in rows if r.get('type') in ('error','turn.failed') or r.get('item',{}).get('status')=='failed'],'committed_writes':0})
write('parity/conditional-decision.json',load(private/'conditional-codex-decision.json'))
write('parity/actual-attempts.json',{'status':'BLOCKED','model':'gpt-6.1-sol','reasoning_effort':'medium','runtime':'original Codex CLI 0.162.0-alpha.17.2 / ChatGPT subscription, no paid API','same_project_root':20606,'same_baseline_revision':2,'input_sha_order':load(private/'codex-control-inputs.json')['source_images'],'attempts':cli_runs,'ranking':'NOT_RUN: transport sandbox, capacity, then MCP approval policy never blocked execution. No direct control geometry committed; no agent performance ranking.','differences':load(private/'codex-control-inputs.json')['differences']})
metrics={'schema_version':1,'elapsed_ms':342610+s['latency_ms'],'elapsed_scope':'Measured website spatial analysis + local edit wall times; excludes human pause and native diagnostics. Critic time is included in edit wall time.','tool_call_count':10+s['tool_call_count'],'failed_tool_calls':1+s['failed_tool_calls'],'committed_writes':2,'full_root_rebuilds':0,'targeted_corrections':1,'input_tokens':547887+s['input_tokens'],'output_tokens':9483+s['output_tokens'],'critic_input_tokens':63556+67600,'critic_output_tokens':751+686,'token_source':'Actual native project_budget_finished and agent_session receipts; separate planner, Builder, Critic, original CLI. Not billing or outer controller token totals.','website_spatial':{'input_tokens':547887,'output_tokens':9483,'latency_ms':342610,'tool_calls':10,'failed_tools':1},'website_local_edit':{'input_tokens':s['input_tokens'],'output_tokens':s['output_tokens'],'latency_ms':s['latency_ms'],'tool_calls':s['tool_call_count'],'failed_tools':s['failed_tool_calls']},'native_P0_model_calls':0,'native_controlled_replays':2,'original_cli_reported_input_subtotal':sum((r['usage'] or {}).get('input_tokens',0) for r in cli_runs),'original_cli_reported_output_subtotal':sum((r['usage'] or {}).get('output_tokens',0) for r in cli_runs),'original_cli_failed_capacity_usage':None,'outer_controller_tokens':None,'paid_api_calls':0}
write('metrics.json',metrics)
write('run.json',{'schema_version':1,'test_id':public.name,'status':'PARTIAL','geometry_committed':True,'base_commit':'74cbafc14cfe2b9135b6a24f2f0a8fdc9ca36e5b','source_case':'Same private eight whole references, architecture-project-4f0e4; original upload order and SHA retained locally and in parity input hashes.','model':{'requested':'GPT-6.1 Sol / Medium','actual':'gpt-6.1-sol','reasoning_effort':'medium','runtime':'K Studio real browser -> Codex App Server -> protected ProjectRuby -> Kongxing -> native SketchUp'},'environment':{'windows':'Windows 11','sketchup':'2024 / 24.0.484','bridge':'Existing Kongxing local bridge, same sole protected writer','adai':'0.5.39 actual deterministic baseline replays; website local edit reuses mesh/definitions, no new ADAI/SAIE calls'},'qa':{'reviewer_mode':'dedicated_read_only','fidelity_status':'FAIL','local_roof_direction':'PASS','deep_keep':'PASS','native_delivery':'PASS','native_mouse_edit_save_reopen':'PASS','spatial_review':'AGENT_REVIEWED_OWNER_DELEGATED','needs_fix':True,'strict_final_blank_replay':'NOT_RUN','original_codex_control':'BLOCKED'},'blockers':['Full-source roof clearance, ramps, internal void/gallery mismatch remain. Original Codex native comparison blocked by MCP approval policy never; transport/capacity attempts are preserved, not model verdict.'],'original_root_pid':20606,'versions':{'original_preserved':1,'zero_model_P0_safe_copy':2,'actual_website_local_edit':3},'outer_controller_model_changed':False,'raw_private_assets_uploaded':False})
errors=[{'stage':'historic_delivery','status':'BLOCKED','reason':'No authenticated historical r1 pre-save capture; not retrospectively reconstructed.'},{'stage':'controlled_original_script_replay','status':'FAIL','reason':'Root-only hashes stayed equal while escaped top-level groups changed/emptied on fresh native reopen.'},{'stage':'collector_first_native_call','status':'FAIL','reason':'JSON string truncated by installed MCP plugin; fixed Hash return, authentic first failure preserved privately.'},{'stage':'native_GUI_checks','status':'RECOVERED','reason':'Application focus changed; invalid Codex folder dialog dismissed. Path/GUID and nil edit-context guards rejected unsafe reads. Native input Type without loc refused; actual mouse probe moved roof +390mm on disposable copy.'},{'stage':'original_Codex_control','status':'BLOCKED','reason':'Host transport sandbox permission, usage-limit interruption, and protected MCP tool requires approval while policy is never. No raw writer bypass or paid inference.'}]
errors += [{'stage':'website_or_critic','run_id':e['run_id'],**r} for e in events for r in e['failed_tools']]
write('errors.json',errors)
tests=(private/'full-checks-publish.txt').read_text(encoding='utf-8',errors='replace');match=re.search(r'(\d+ passed, \d+ skipped[^\n]*)',tests);write('checks.json',{'pytest':match.group(1) if match else 'UNKNOWN','node_syntax':'PASS','python_compileall':'PASS','native_transaction_negative':'PASS','critic_duplicate_image_patch':'Tested offline; real post-patch Critic NOT_RUN; no measured model quality/cost savings claimed.'})
print('Public actual evidence exported; no raw photos, SKP or private execution logs.')

$ErrorActionPreference = 'Stop'
$controlInfo = Get-Content -LiteralPath 'runtime/native-recovery-20261014/codex-control-inputs.json' -Raw | ConvertFrom-Json
$controlWorkspace = Join-Path (Get-Location) 'runtime/native-recovery-20261014/codex-control/projects/architecture-project-4f0e4/runtime/agent_workspace'
$controlArgs = @('exec','--skip-git-repo-check','--json','-C',$controlWorkspace,'-m','gpt-6.1-sol','-c','model_reasoning_effort="medium"','-s','workspace-write')
foreach ($serverName in @('kongxing_sketchup','unityMCP','honglu-autocad','windows-mcp','node_repl')) {
    $controlArgs += @('-c',"mcp_servers.$serverName.enabled=false")
}
$controlArgs += @('-c','mcp_servers.kstudio_guarded_control.command="E:/K AI 产品建模网站/.venv/Scripts/python.exe"','-c',('mcp_servers.kstudio_guarded_control.args=["'+($controlWorkspace.Replace('\','/')+'/control_mcp.py')+'"]'))
foreach ($sourceItem in $controlInfo.source_images) { $controlArgs += @('-i',$sourceItem.path) }
$controlArgs += @('-c','project_root_markers=[".codex-control-root"]')
$controlArgs += @('-c','approval_policy="never"','-c','mcp_servers.kstudio_guarded_control.tools.sketchup_control.approval_mode="approve"')
$controlArgs += @('--','从坡道这一端看，屋顶还是左边偏高。请按原图改成右边高、左边低，保留曲面，坡道和其他部分别动。')
$controlStart = [DateTimeOffset]::UtcNow
& codex @controlArgs 1> 'runtime/original-cli-authorized-20261014/original-codex-boundary-retry.jsonl' 2> 'runtime/original-cli-authorized-20261014/original-codex-boundary-retry.stderr.txt'
$controlExit = $LASTEXITCODE
@{ started_at=$controlStart.ToString('o'); completed_at=[DateTimeOffset]::UtcNow.ToString('o'); elapsed_ms=[int](([DateTimeOffset]::UtcNow-$controlStart).TotalMilliseconds); exit_code=$controlExit } | ConvertTo-Json | Set-Content -LiteralPath 'runtime/original-cli-authorized-20261014/original-codex-boundary-retry-timing.json' -Encoding utf8
exit $controlExit

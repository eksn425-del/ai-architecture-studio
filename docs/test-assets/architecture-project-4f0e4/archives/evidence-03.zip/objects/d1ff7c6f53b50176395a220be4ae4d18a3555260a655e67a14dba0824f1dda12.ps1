$ErrorActionPreference = 'Stop'
$controlWorkspace = Join-Path (Get-Location) 'runtime/native-recovery-20261014/codex-control/projects/architecture-project-4f0e4/runtime/agent_workspace'
$controlArgs = @('exec','--skip-git-repo-check','--json','-C',$controlWorkspace,'-m','gpt-6.1-sol','-c','model_reasoning_effort="medium"','-s','workspace-write')
foreach ($serverName in @('kongxing_sketchup','unityMCP','honglu-autocad','windows-mcp','node_repl')) {$controlArgs += @('-c',"mcp_servers.$serverName.enabled=false")}
$controlArgs += @('-c','mcp_servers.kstudio_guarded_control.command="E:/K AI 产品建模网站/.venv/Scripts/python.exe"','-c',('mcp_servers.kstudio_guarded_control.args=["'+($controlWorkspace.Replace('\','/')+'/control_mcp.py')+'"]'))
$controlArgs += @('resume','01a138a0-f5fa-70c3-9ad3-2113e366c3dc','--','继续刚才这一次屋顶局部修改，还是原八张图和原安全副本，其他部分别动。')
$controlStart=[DateTimeOffset]::UtcNow
& codex @controlArgs 1> 'runtime/native-recovery-20261014/original-codex-resume.jsonl' 2> 'runtime/native-recovery-20261014/original-codex-resume.stderr.txt'
$controlExit=$LASTEXITCODE
@{started_at=$controlStart.ToString('o');completed_at=[DateTimeOffset]::UtcNow.ToString('o');elapsed_ms=[int](([DateTimeOffset]::UtcNow-$controlStart).TotalMilliseconds);exit_code=$controlExit} | ConvertTo-Json | Set-Content -LiteralPath 'runtime/native-recovery-20261014/original-codex-resume-timing.json' -Encoding utf8
exit $controlExit

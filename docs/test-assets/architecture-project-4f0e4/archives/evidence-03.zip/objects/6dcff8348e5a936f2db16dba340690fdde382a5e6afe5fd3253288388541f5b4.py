from pathlib import Path
import json,shutil,hashlib
from app.harness_parity_policy import decide_codex_baseline
out=Path.cwd()/'runtime/native-recovery-20261014';source=Path.cwd()/'runtime/projects/architecture-project-4f0e4'
assert json.loads((out/'site-r3-three-stage-audit.json').read_text(encoding='utf-8'))['status']=='PASS'
decision=decide_codex_baseline(delivery='PASS',first_pass_source='FAIL',local_edit='PASS',natural_ux='PASS')
(out/'conditional-codex-decision.json').write_text(json.dumps(decision,indent=2),encoding='utf-8');assert decision['decision']=='RUN_SAME_SOURCE_NATIVE_CODEX_CONTROL'
runtime=out/'codex-control';p=runtime/'projects'/source.name;workspace=p/'runtime/agent_workspace';workspace.mkdir(parents=True,exist_ok=False)
for folder in ('scripts','notes','qa'):(workspace/folder).mkdir()
(p/'outputs/model').mkdir(parents=True);(p/'inputs/reference').mkdir(parents=True)
baseline=source/'outputs/model/blank-disposable-p0-bound-FRESH-r2.skp';model=p/'outputs/model/blank-disposable-original-codex-r2.skp';shutil.copy2(baseline,model)
context=json.loads((source/'state/project_context.json').read_text(encoding='utf-8'));order=[]
for r in context['references']:
 if r.get('type')=='image' and r['source'].startswith('inputs/reference/'):
  f=source/r['source'];dest=p/r['source'];shutil.copy2(f,dest);order.append({'path':str(dest),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
assert len(order)==8
state=json.loads((out/'pre-working-copy-bind-project_ruby_state.json').read_text(encoding='utf-8'))
state['model_path']=str(model);state['scripts']['glass_curved_roof']['revision']=2
(p/'runtime/project_ruby_state.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
for n in ('spatial_spec.json','reconstruction_card.md'):shutil.copy2(source/'runtime/agent_workspace/notes'/n,workspace/'notes'/n)
shutil.copy2(out/'parent-first-reconstruction.rb',workspace/'scripts/original_parent_first_baseline.rb')
(out/'codex-control-inputs.json').write_text(json.dumps({'original_project':source.name,'root_pid':20606,'baseline_revision':2,'baseline_skp_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),'source_images':order,'model':'gpt-6.1-sol','reasoning_effort':'medium','runtime':'original codex exec 0.162.0-alpha.17.2 / ChatGPT login','differences':['Direct original CLI rather than K Studio app-server UI. Same guarded ProjectRuby/Kongxing via host Python entry point, no raw writer tools.','Same safe r2 baseline and eight inputs; independent site Critics are preserved but CLI has host/outer read-only review after execution instead of repeating site Critic orchestration.','Scoped local edit comparison only; no new full-building first pass or new architecture case.']},indent=2),encoding='utf-8')
print('Prepared conditional original CLI control, same project/root/r2 baseline/eight source SHA order.')

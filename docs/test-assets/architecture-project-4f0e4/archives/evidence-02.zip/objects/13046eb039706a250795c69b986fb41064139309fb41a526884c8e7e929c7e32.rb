# One owned roof edit: reflect the existing assemblies across root-local Y=10000 mm.
# No geometry recreation, material edits, or operations/save calls: host owns transaction.
raise 'Unexpected owned root' unless root.persistent_id == 20606
roof = root.entities.find { |e| e.is_a?(Sketchup::Group) && e.name == 'ROOF_TIMBER' }
envelope = root.entities.find { |e| e.is_a?(Sketchup::Group) && e.name == 'ENVELOPE_OUTER' }
raise 'Roof identity mismatch' unless roof && roof.persistent_id == 77872
raise 'Envelope identity mismatch' unless envelope && envelope.persistent_id == 41319
bracing = envelope.entities.find { |e| e.is_a?(Sketchup::Group) && e.name == 'TENSION_BRACING' }
supports = roof.entities.find { |e| e.is_a?(Sketchup::Group) && e.name == 'ROOF_SUPPORTS' }
shell = roof.entities.find { |e| e.is_a?(Sketchup::Group) && e.name == 'CURVED_SHELL' }
raise 'Roof assembly missing' unless bracing && supports && shell
raise 'Bracing identity mismatch' unless bracing.persistent_id == 44694
posts = ['TIMBER_POST_0_0', 'TIMBER_POST_0_1'].map do |name|
  supports.entities.find { |e| e.respond_to?(:name) && e.name == name }
end
raise 'Edge posts missing' unless posts.all?
edge_positions = lambda do
  posts.map do |post|
    b = post.bounds
    roof.transformation * supports.transformation * Geom::Point3d.new(b.center.x, b.center.y, b.max.z)
  end.sort_by(&:y)
end
before = edge_positions.call
raise 'Current roof is not left high as expected' unless before[1].z > before[0].z + 900.mm
mirror = Geom::Transformation.scaling(Geom::Point3d.new(0, 10000.mm, 0), 1.0, -1.0, 1.0)
# Roof transformation is expressed in owned-root coordinates.
roof.transform!(mirror)
# Bracing has an additional envelope parent; conjugate to that parent's coordinates.
bracing.transform!(envelope.transformation.inverse * mirror * envelope.transformation)
after = edge_positions.call
raise 'Requested right high / left low failed' unless after[0].z > after[1].z + 900.mm
raise 'Edge heights changed' unless (before[0].z-after[1].z).abs < 0.01.mm && (before[1].z-after[0].z).abs < 0.01.mm

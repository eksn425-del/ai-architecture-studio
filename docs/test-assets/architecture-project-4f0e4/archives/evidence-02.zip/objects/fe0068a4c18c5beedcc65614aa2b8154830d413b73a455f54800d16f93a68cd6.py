from pathlib import Path
import json,shutil,sys
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP
from app.project_ruby import ProjectRubyExecutor
from app.agent_tools import AgentToolSurface
out=Path.cwd()/'runtime/native-recovery-20261014';runtime=Path.cwd()/'runtime';p=runtime/'projects/architecture-project-4f0e4'
client=ConfiguredSketchUpMCP();ad=SketchUpAdapter(client);i=ad.get_active_model_identity();s=json.loads((p/'state/agent_session.json').read_text(encoding='utf-8'));model=p/s['model_path'];assert Path(i['model_path']).resolve()==model.resolve()
ex=ProjectRubyExecutor(runtime,p.name,expected_model_path=model,expected_model_guid=i['model_guid'],mcp=client,ruby_state=s['ruby_state'],adapter=ad);surface=AgentToolSurface(runtime,client,oss_backends={});dest=out/sys.argv[1];dest.mkdir(exist_ok=False)
for name in ('front','rear','left','right','roof','oblique'):
 r=surface.dispatch('sketchup_capture_canonical_view',{'script_id':'glass_curved_roof','view_name':name},project_dir=p,project_ruby=ex)
 f=p/r['visual_evidence']['path'];shutil.copy2(f,dest/(name+'.png'));shutil.copy2(f.with_suffix('.evidence.json'),dest/(name+'.evidence.json'))
 print(name,'captured r',s['ruby_state']['glass_curved_roof']['revision'])
ad.set_camera([-65,12,18],[25,12,8]);ad.capture_view(dest/'source-perspective.png',zoom_extents=False)

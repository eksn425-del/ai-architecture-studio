from pathlib import Path
import sys,json
from app.sketchup_mcp import SketchUpAdapter
out=Path.cwd()/'runtime/native-recovery-20261014';ad=SketchUpAdapter();i=ad.get_active_model_identity()
expected=Path(sys.argv[1]).resolve();assert Path(i['model_path']).resolve()==expected,(i['model_path'],expected)
d=ad.capture_native_deep_fingerprint(expected_model_path=expected,expected_guid=i['model_guid'],root_pid=20606,output_path=out/sys.argv[2])
print('Actual fresh native capture',sys.argv[2],d['document_geometry_material_sha256'])

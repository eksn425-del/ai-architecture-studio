import json
from pathlib import Path
b=json.loads(Path('qa/before-write.json').read_text(encoding='utf-8'))
a=json.loads(Path('qa/after-write-before-save.json').read_text(encoding='utf-8'))
bg={g['name']:g for g in b['groups']}; ag={g['name']:g for g in a['groups']}
changed=[k for k in bg if bg[k]!=ag[k]]
print('Changed top-level subtrees:',changed)
assert set(changed)=={'ROOF_TIMBER','ENVELOPE_OUTER'}
be={g['name']:g for g in bg['ENVELOPE_OUTER']['children']}; ae={g['name']:g for g in ag['ENVELOPE_OUTER']['children']}
env_changed=[k for k in be if be[k]!=ae[k]]
print('Changed envelope subtrees:',env_changed)
assert env_changed==['TENSION_BRACING']
assert b['counts']==a['counts']
print('Unchanged model counts:',a['counts'])
def local_metadata(node):
 return {k:([local_metadata(c) for c in v] if k=='children' else v) for k,v in node.items() if k not in ['world_transform','geometry_material_sha256','definition_instances']}
for old,new in [(bg['ROOF_TIMBER'],ag['ROOF_TIMBER']),(be['TENSION_BRACING'],ae['TENSION_BRACING'])]:
 om=local_metadata(old); nm=local_metadata(new)
 om.pop('local_transform'); nm.pop('local_transform')
 assert om==nm
 assert new['local_transform']==[1,0,0,0,0,-1,0,0,0,0,1,0,0,20000,0,1]
 print(new['name'],'exact Y reflection; identical descendant local transforms, definition GUIDs, identities, counts and tags. World-coordinate hashes change as expected.')
w=json.loads(Path('qa/write-result.json').read_text(encoding='utf-8'))
for item in w['contentItems']:
 if item.get('type')=='inputText':
  try:r=json.loads(item['text'])
  except (KeyError,ValueError):continue
  print('Transaction:',r.get('transaction',{}).get('status'),'revision:',r.get('script_revision'))
  print('Protection:',r.get('edit_scope_receipt',{}).get('status'))
p=Path('../..')/'outputs/model/original-codex-local-r3.skp'
print('Saved file exists:',p.exists(),'bytes:',p.stat().st_size if p.exists() else None)

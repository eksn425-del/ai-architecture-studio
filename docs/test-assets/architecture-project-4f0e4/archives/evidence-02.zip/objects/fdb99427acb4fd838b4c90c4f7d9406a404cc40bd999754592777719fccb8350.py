"""Private one-edit experiment entry point; reuse existing product writer, not a new geometry engine."""
from pathlib import Path
import json,sys
REPO=Path('E:/K AI 产品建模网站');sys.path.insert(0,str(REPO))
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP
from app.project_ruby import ProjectRubyExecutor
from app.agent_tools import AgentToolSurface
workspace=Path(__file__).resolve().parent;p=workspace.parents[1];runtime=p.parents[1]
client=ConfiguredSketchUpMCP(timeout_seconds=180);ad=SketchUpAdapter(client);identity=ad.get_active_model_identity();state=json.loads((p/'runtime/project_ruby_state.json').read_text(encoding='utf-8'))
model=Path(state['model_path']);assert Path(identity['model_path']).resolve()==model.resolve(),'Active control document differs'
ex=ProjectRubyExecutor(runtime,p.name,expected_model_path=model,expected_model_guid=identity['model_guid'],mcp=client,ruby_state=state['scripts'],adapter=ad)
surface=AgentToolSurface(runtime,client,oss_backends={});action=sys.argv[1];args=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8')) if len(sys.argv)>2 else {}
if action=='inspect':
 r=surface.dispatch('sketchup_inspect_owned',{'script_id':'glass_curved_roof',**args},project_dir=p,project_ruby=ex)
elif action=='capture':
 r=surface.dispatch('sketchup_capture_canonical_view',{'script_id':'glass_curved_roof',**args},project_dir=p,project_ruby=ex)
elif action=='source_view':
 ad.set_camera([-65,12,18],[25,12,8]);dest=workspace/'qa/source-perspective.png';ad.capture_view(dest,zoom_extents=False);r={'image_path':str(dest)}
elif action=='run':
 assert ex.ruby_state['glass_curved_roof']['revision']==2,'One committed edit maximum; no full rebuild'
 assert args.get('update_mode')=='edit' and args.get('script_id')=='glass_curved_roof'
 assert args.get('allowed_mutation_paths')==[['ROOF_TIMBER'],['ENVELOPE_OUTER']],'Only roof and its envelope bracing may change'
 original=json.loads((REPO/'runtime/native-recovery-20261014/owned-copy-live-before-save.json').read_text(encoding='utf-8'))
 paths=[[g['name']] for g in original['groups'] if g['name'] not in {'ROOF_TIMBER','ENVELOPE_OUTER'}]
 env=next(g for g in original['groups'] if g['name']=='ENVELOPE_OUTER');paths += [['ENVELOPE_OUTER',g['name']] for g in env['children'] if g['name']!='TENSION_BRACING']
 snapshots=ex.inspect_owned_batch('glass_curved_roof',paths)
 keep=[{'path':path,'persistent_id':snapshot['persistent_id'],'objects_total':snapshot['objects_total'],'bounds_mm':snapshot['bounds_mm']} for path,snapshot in zip(paths,snapshots)]
 # Inspect returns content items from the existing protected writer. The host
 # owns these expectations; the CLI cannot author a success receipt.
 args['_keep_expectations']=keep
 before=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=ad.get_active_model_identity()['model_guid'],root_pid=20606,output_path=workspace/'qa/before-write.json')
 r=surface.dispatch('sketchup_run_workspace_ruby',args,project_dir=p,project_ruby=ex)
 (workspace/'qa/write-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 after=ad.capture_native_deep_fingerprint(expected_model_path=model,expected_guid=ad.get_active_model_identity()['model_guid'],root_pid=20606,output_path=workspace/'qa/after-write-before-save.json')
 ad.save_model(model,expected_root_ids=[20606]);ad.save_model(p/'outputs/model/original-codex-local-r3.skp',expected_root_ids=[20606])
else:raise ValueError('Use inspect, capture, source_view, or run')
for item in r.get('contentItems',[]):
 if item.get('type')=='inputText':print(item.get('text',''))
if r.get('visual_evidence'):print(json.dumps(r['visual_evidence']))
if r.get('image_path'):print(r['image_path'])

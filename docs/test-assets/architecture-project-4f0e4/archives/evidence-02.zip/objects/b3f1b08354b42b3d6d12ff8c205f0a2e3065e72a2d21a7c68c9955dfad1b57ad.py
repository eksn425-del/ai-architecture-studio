"""Private adapter around existing guarded product tools for original CLI control."""
from pathlib import Path
import json,subprocess,uuid
from mcp.server.fastmcp import FastMCP
workspace=Path(__file__).resolve().parent
server=FastMCP('KStudioGuardedControl')
@server.tool()
def sketchup_control(action: str, arguments: dict) -> str:
    """Inspect/capture/source_view/run the SAME safe original root with existing protected ProjectRuby/Kongxing. See workspace AGENTS.md for arguments; one edit maximum."""
    if action not in {'inspect','capture','source_view','run'}:raise ValueError('Unknown control action')
    request=workspace/'qa'/('host-request-'+uuid.uuid4().hex+'.json');request.write_text(json.dumps(arguments,ensure_ascii=False),encoding='utf-8')
    result=subprocess.run(['E:/K AI 产品建模网站/.venv/Scripts/python.exe',str(workspace/'host_adapter.py'),action,str(request)],cwd=workspace,stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180,env={**__import__('os').environ,'PYTHONIOENCODING':'utf-8'})
    if result.returncode:raise RuntimeError(result.stderr[-4000:])
    return result.stdout
server.run(transport='stdio')

from pathlib import Path
import json,shutil
from app.sketchup_mcp import SketchUpAdapter,ConfiguredSketchUpMCP
from app.project_ruby import ProjectRubyExecutor
from app.agent_tools import AgentToolSurface
out=Path.cwd()/'runtime/native-recovery-20261014';controlled=out/'controlled';project=controlled/'projects/architecture-project-4f0e4'
model=project/'outputs/model/parent-first-download.skp'
# The canonical host requires a blank-disposable filename. Use the already
# reopened bound copy when running this script, not the download candidate.
model=project/'outputs/model/blank-disposable-parent-first-FRESH-bound.skp'
client=ConfiguredSketchUpMCP();ad=SketchUpAdapter(client);i=ad.get_active_model_identity()
saved=json.loads((project/'runtime/project_ruby_state.json').read_text(encoding='utf-8'))['scripts']
ex=ProjectRubyExecutor(controlled,project.name,expected_model_path=model,expected_model_guid=i['model_guid'],mcp=client,ruby_state=saved,adapter=ad)
surface=AgentToolSurface(controlled,client,oss_backends={})
destination=out/'repaired-views';destination.mkdir(exist_ok=True)
for name in ('front','rear','left','right','roof','oblique'):
 r=surface.dispatch('sketchup_capture_canonical_view',{'script_id':'glass_curved_roof','view_name':name},project_dir=project,project_ruby=ex)
 p=project/r['visual_evidence']['path'];shutil.copy2(p,destination/(name+'.png'));shutil.copy2(p.with_suffix('.evidence.json'),destination/(name+'.evidence.json'))
 print('captured',name)
ad.set_camera([-65,-48,35],[25,10,8]);ad.capture_view(out/'parent-first-reopened-oblique.png',zoom_extents=False)
